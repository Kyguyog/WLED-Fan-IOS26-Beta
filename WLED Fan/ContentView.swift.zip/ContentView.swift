import SwiftUI

struct ContentView: View {
    @StateObject private var manager = WLEDManager()
    @State private var fanSpeed: Double = 128
    @State private var showingSettings = false

    var body: some View {
        VStack(spacing: 0) {
            // Expand to fill all available space above the controls
            Group {
                if let device = manager.selectedDevice,
                   let url = URL(string: "http://\(device.ip)") {
                    WebView(url: url)
                } else {
                    Text("No WLED device selected.")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color.gray.opacity(0.1))
                }
            }
            .frame(maxWidth: .infinity)
            .frame(maxHeight: .infinity)
            .clipped()

            Divider()

            VStack(spacing: 12) {
                HStack {
                    Text("PWM Fan: \(Int(fanSpeed))")
                    Spacer()
                    Button("Devices") {
                        showingSettings = true
                    }
                }

                Slider(value: $fanSpeed, in: 0...255, step: 1) {
                    Text("Fan Speed")
                } onEditingChanged: { editing in
                    if !editing {
                        sendPWM()
                    }
                }
            }
            
            .padding()
            .background(Color(UIColor.systemBackground)) // ensure it's visible on light/dark
        }
        .edgesIgnoringSafeArea(.bottom) // optional if you want the slider at the very bottom
        .sheet(isPresented: $showingSettings) {
            SettingsView(manager: manager)
        }
    }
    func sendPWM() {
        guard let device = manager.selectedDevice else { return }
        let urlString = "http://\(device.ip)/win&PWM=\(Int(fanSpeed))"
        guard let url = URL(string: urlString) else { return }
        URLSession.shared.dataTask(with: url).resume()
    }
}
